package com.acme.spring_cloud_service_hello_world;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudServiceHelloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
