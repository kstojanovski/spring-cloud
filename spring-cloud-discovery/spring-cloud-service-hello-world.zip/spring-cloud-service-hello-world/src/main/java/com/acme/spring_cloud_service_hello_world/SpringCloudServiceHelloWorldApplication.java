package com.acme.spring_cloud_service_hello_world;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudServiceHelloWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudServiceHelloWorldApplication.class, args);
	}

}
