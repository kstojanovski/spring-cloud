package com.acme.spring_cloud_service_world;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudServiceWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
