package com.acme.spring_cloud_service_world;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudServiceWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudServiceWorldApplication.class, args);
	}

}
