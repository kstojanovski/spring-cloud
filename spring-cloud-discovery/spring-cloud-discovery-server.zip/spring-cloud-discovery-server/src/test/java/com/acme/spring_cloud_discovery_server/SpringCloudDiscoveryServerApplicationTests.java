package com.acme.spring_cloud_discovery_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
